﻿using BepInEx;
using SAIN.Vision.Config;
using System;

namespace SAIN.Vision
{
    [BepInPlugin("me.sol.sainvision", "SAIN Vision", "1.2")]
    public class VisionPlugin : BaseUnityPlugin
    {
        private void Awake()
        {
            try
            {
                Vision.Config.Vision.Init(Config);

                new Patches.VisibleDistancePatch().Enable();
                new Patches.GainSightPatch().Enable();
                new Patches.VisionOverridesPatch().Enable();
            }
            catch (Exception ex)
            {
                Logger.LogError($"{GetType().Name}: {ex}");
                throw;
            }
        }
    }
}