﻿using BepInEx;
using SAIN.Combat.Configs;
using System;

namespace SAIN.Combat
{
    [BepInPlugin("me.sol.sain", "SAIN Combat", "1.6")]
    public class CombatPlugin : BaseUnityPlugin
    {
        private void Awake()
        {
            try
            {
                Fullauto.Init(Config);
                Firerate.Init(Config);
                Debug.Init(Config);

                new Patches.AddComponentPatch().Enable();

                new Patches.BotGlobalScatterPatch().Enable();
                new Patches.BotGlobalShootDataPatch().Enable();
                new Patches.BotGlobalCorePatch().Enable();

                new Patches.SetVisiblePatch().Enable();
                new Patches.UpdateRatePatch().Enable();

                new Patches.AimPatch().Enable();
                new Patches.ScatterPatch().Enable();
                new Patches.RecoilPatch().Enable();

                new Patches.FullAutoPatch_1().Enable();
                new Patches.FullAutoPatch_2().Enable();
                new Patches.FiremodeSwapPatch().Enable();
                new Patches.SemiAutoPatch().Enable();
            }
            catch (Exception ex)
            {
                Logger.LogError($"{GetType().Name}: {ex}");
                throw;
            }
        }
    }
}