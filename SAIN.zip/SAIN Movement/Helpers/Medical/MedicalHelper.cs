﻿using EFT;

namespace SAIN.Movement.Helpers
{
    public class Medical
    {
        //static float healTime = 0.0f;
        //static float hitCount = 0.0f;
        //static bool isEnemyHurt = false;
        //static bool isFallingBack = false;
        //static bool isDodging = false;
        //static bool DodgeDir = true;
        //static bool isHealing = false;
        //static string currentEnemyID;

        public static void SelfCheck(BotOwner bot)
        {
            /*
            isHealing = ___botOwner_0.Medecine.Using && (healTime < Time.time + 20f);
            //Fall back to heal
            if (isHurt && !isHealing)
            {
                if (!isFallingBack)
                {
                }
                isHealing = true;
                healTime = Time.time;
                isFallingBack = true;
                ___botOwner_0.Medecine.Stimulators.TryApply(true, null, null);
                ___botOwner_0.Medecine.FirstAid.SetRandomPartToHeal();
                ___botOwner_0.Medecine.FirstAid.TryApplyToCurrentPart(null, null);

                _DogFightStateSetter.Invoke(__instance, new object[] { BotDogFightStatus.none });

                if (SAIN.DebugDogFighter.Value == true)
                {
                    Logger.LogInfo($"Dogfighter {___botOwner_0.name}: I'm injured! - trying to heal up");
                }
                return false;
            }
            */
        }
    }
}
