﻿using BepInEx;
using SAIN.Flashlights.Config;
using System;

namespace SAIN.Flashlights
{
    [BepInPlugin("me.sol.sainflash", "SAIN Flashlights", "1.1")]
    public class FlashlightsPlugin : BaseUnityPlugin
    {
        private void Awake()
        {
            Dazzle.Init(Config);

            try
            {
                new Patches.FlashLightDazzle().Enable();
            }
            catch (Exception ex)
            {
                Logger.LogError($"{GetType().Name}: {ex}");
                throw;
            }
        }
    }
}