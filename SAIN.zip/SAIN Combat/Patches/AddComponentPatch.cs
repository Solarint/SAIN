﻿using Aki.Reflection.Patching;
using EFT;
using HarmonyLib;
using System.Reflection;
using SAIN.Combat.Components;

namespace SAIN.Combat.Patches
{
    public class AddComponentPatch : ModulePatch
    {
        protected override MethodBase GetTargetMethod()
        {
            return AccessTools.Method(typeof(BotOwner), "PreActivate");
        }

        [PatchPostfix]
        public static void PatchPostfix(ref BotOwner __instance)
        {
            __instance.gameObject.AddComponent<WeaponInfo>();
        }
    }
    public class BotGlobalShootDataPatch : ModulePatch
    {
        protected override MethodBase GetTargetMethod()
        {
            return AccessTools.Method(typeof(BotGlobalShootData), "Update");
        }
        [PatchPostfix]
        public static void PatchPostfix(BotGlobalShootData __instance)
        {
            __instance.CHANCE_TO_CHANGE_TO_AUTOMATIC_FIRE_100 = 100f;
            __instance.AUTOMATIC_FIRE_SCATTERING_COEF = 5f;
            __instance.BASE_AUTOMATIC_TIME = 0.5f;
            __instance.RECOIL_TIME_NORMALIZE = 0.25f;
            __instance.RECOIL_PER_METER = 1.0f;
            __instance.MAX_RECOIL_PER_METER = 3.0f;
            __instance.HORIZONT_RECOIL_COEF = 1f;
            __instance.RECOIL_DELTA_PRESS = 0f;
        }
    }
    public class BotGlobalScatterPatch : ModulePatch
    {
        protected override MethodBase GetTargetMethod()
        {
            return AccessTools.Method(typeof(BotGlobalsScatteringSettings), "Update");
        }
        [PatchPostfix]
        public static void PatchPostfix(BotGlobalsScatteringSettings __instance)
        {
            __instance.MinScatter = 0.25f;
            __instance.WorkingScatter = 0.5f;
            __instance.MaxScatter = 5.0f;

            // NONE OF THESE ARE USED, THEY LEAD TO UN-USED CLASS FILES
            //__instance.SpeedUp = 0.15f;
            //__instance.SpeedUpAim = 1.1f;
            //__instance.SpeedDown = -0.3f;
            //__instance.FromShot = 0.1f;

            //__instance.ToSlowBotSpeed = 0.1f;
            //__instance.ToLowBotSpeed = 0.1f;
            //__instance.ToUpBotSpeed = 0.1f;
            //__instance.MovingSlowCoef = 2.5f;

            //__instance.ToLowBotAngularSpeed = 80f;
            //__instance.ToStopBotAngularSpeed = 40f;

            //__instance.TracerCoef = 1f;
            //__instance.HandDamageScatteringMinMax = 3.0f;
            //__instance.HandDamageAccuracySpeed = 3f;
            //__instance.BloodFall = 1.45f;
            //__instance.ToCaution = 1f;

            //__instance.RecoilControlCoefShootDone = 0.1f; // 0.0003f;
            //__instance.RecoilControlCoefShootDoneAuto = 0.1f; // 0.00015f;

            //__instance.DIST_FROM_OLD_POINT_TO_NOT_AIM_SQRT = 0.25f * 0.25f;

            //__instance.AMPLITUDE_FACTOR = 0.5f;
            //__instance.AMPLITUDE_SPEED = 0.1f;
            //__instance.DIST_NOT_TO_SHOOT = 0.1f;
            //__instance.LayFactor = 1f;
            //__instance.RecoilYCoef = 0.0005f;
            //__instance.RecoilYCoefSppedDown = -0.52f;
            //__instance.RecoilYMax = 1f;
        }
    }
    public class BotGlobalCorePatch : ModulePatch
    {
        protected override MethodBase GetTargetMethod()
        {
            return AccessTools.Method(typeof(GClass559), "Update");
        }
        [PatchPostfix]
        public static void PatchPostfix(GClass559 __instance)
        {
            __instance.SHOOT_TO_CHANGE_RND_PART_DELTA = 0.25f;
            __instance.CAN_SHOOT_TO_HEAD = false;
            __instance.ARMOR_CLASS_COEF = 7f;
            __instance.SHOTGUN_POWER = 70f;
            __instance.RIFLE_POWER = 50f;
            __instance.PISTOL_POWER = 30f;
            __instance.SMG_POWER = 100f;
            __instance.SNIPE_POWER = 20f;
        }
    }
}
