To Install: Drop it in the SPTarkov main folder.

Version 1.1
New: If an AI is wearing nightvision and is blinded by a flashlight, it will be more effective and blind them for longer.

Added very important new features:
Dynamic Context based Funny mode.
It makes the ai say funny stuff when blinded and makes them completely helpless.

Version 1.0
AI are now affected by flashlights. Their scatter and aim all get progressively worse the closer they are to the flashlight.
You can change the intensity in the f12 settings.
Scavs are much more affected by this than other bot types. Not 100% intentional, and will likely be changed in the future.
Default settings are balanced around PMC types and other harder AI, I didn't want to make it overpowered, but also wanted it to have at least some obvious effects.
Theres also an option to have the ai play a random aggressive voice line when being dazzled (4% chance) Its on by default, but you can turn it off of course.
Advanced Options include: Angle modifier for how wide of an angle to dazzle bots, and a distance start, where you can change the maximum dazzle distance and have it scale accordingly. Default is 25m max range.

It's a very simple mod, but if you have any issues, let me know and I'll try to get it fixed ASAP.
