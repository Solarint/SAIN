﻿using BepInEx;
using SAIN.Audio.Configs;
using System;

namespace SAIN.Audio
{
    [BepInPlugin("me.sol.sainaudio", "SAIN Audio", "1.2")]
    public class AudioPlugin : BaseUnityPlugin
    {
        private void Awake()
        {
            Sound.Init(Config);
            try
            {
                new Patches.InitiateShotPatch().Enable();
                new Patches.TryPlayShootSoundPatch().Enable();
                new Patches.ComponentAddPatch().Enable();
                new Patches.HearingSensorDisablePatch().Enable();
            }
            catch (Exception ex)
            {
                Logger.LogError($"{GetType().Name}: {ex}");
                throw;
            }
        }
    }
}