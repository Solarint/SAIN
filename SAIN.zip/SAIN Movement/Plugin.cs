﻿using BepInEx;
using SAIN.Movement.Config;
using System;

namespace SAIN.Movement
{
    [BepInPlugin("me.sol.sainmove", "SAIN Movement", "1.5")]
    [BepInProcess("EscapeFromTarkov.exe")]
    public class SAIN : BaseUnityPlugin
    {
        private void Awake()
        {
            try
            {
                DogFighter.Init(Config);
                Debug.Init(Config);
                //Door.Init(Config);

                new Patches.AddComponentPatch().Enable();
                new Patches.BotGlobalsMindSettingsPatch().Enable();

                new Patches.MovementSpeed().Enable();
                new Patches.DodgePatch().Enable();

                //new Patches.CoverPatch().Enable();
                //new Patches.DoorPatch().Enable();
            }
            catch (Exception ex)
            {
                Logger.LogError($"{GetType().Name}: {ex}");
                throw;
            }
        }
    }
}