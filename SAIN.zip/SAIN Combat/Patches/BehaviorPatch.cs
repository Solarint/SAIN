﻿using Aki.Reflection.Patching;
using EFT;
using EFT.InventoryLogic;
using HarmonyLib;
using SAIN.Combat.Helpers;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using static SAIN.Combat.Configs.Fullauto;

namespace SAIN.Combat.Patches
{
    public class SetVisiblePatch : ModulePatch
    {
        protected override MethodBase GetTargetMethod()
        {
            // These properties are "read only" So we must use reflection
            _IsVisible = AccessTools.PropertySetter(typeof(GClass475), "IsVisible");
            _FirstTimeSeen = AccessTools.PropertySetter(typeof(GClass475), "FirstTimeSeen");
            _PersonalSeenTime = AccessTools.PropertySetter(typeof(GClass475), "PersonalSeenTime");

            return AccessTools.Method(typeof(GClass475), "SetVisible");
        }

        // Save the method info for the "read only" properties
        private static MethodInfo _IsVisible;
        private static MethodInfo _FirstTimeSeen;
        private static MethodInfo _PersonalSeenTime;

        [PatchPrefix]
        public static bool PatchPrefix(GClass475 __instance, bool value)
        {
            // save "value" as a bool that is easier to understand for readability
            bool isNowVisible = value;

            // Save the old state of "visibility" for use in logic, then set the new visible status
            bool wasVisible = __instance.IsVisible;
            _IsVisible.Invoke(__instance, new object[] { isNowVisible });

            // Test - Adding delay to every aim attempt.
            if (__instance.Owner.Memory.GoalEnemy != null)
            {
                __instance.Owner.AimingData.SetNextAimingDelay(0.1f);
            }

            // If the enemy was previously visible, but is now not visible then:
            if (!isNowVisible && wasVisible)
            {
                if (__instance.Owner.Memory.GoalEnemy != null && __instance.Owner.Memory.GoalEnemy == __instance)
                {
                    __instance.Owner.Memory.LoseVisionCurrentEnemy();

                    if (__instance.Owner.BotsGroup.GroupTalk.CanSay(__instance.Owner, EPhraseTrigger.LostVisual))
                    {
                        __instance.Owner.GetPlayer.Say(EPhraseTrigger.LostVisual, false, 0.50f, ETagStatus.Combat, 50, true);
                    }
                }
                __instance.GroupOwner.LoseVision(__instance.Person);
            }

            // If the enemy was not previously visible, but is now visible then:
            if (isNowVisible && !wasVisible)
            {
                // Test - Adding delay to every aim attempt.
                __instance.Owner.AimingData.SetNextAimingDelay(0.25f);

                if (!__instance._haveSeenPersonal)
                {
                    __instance._haveSeenPersonal = true;
                    _FirstTimeSeen.Invoke(__instance, new object[] { Time.time });

                    if (__instance.Owner.BotsGroup.GroupTalk.CanSay(__instance.Owner, EPhraseTrigger.OnFirstContact))
                    {
                        __instance.Owner.GetPlayer.Say(EPhraseTrigger.OnFirstContact, false, 0.33f, ETagStatus.Combat, 50, true);
                    }
                }

                _PersonalSeenTime.Invoke(__instance, new object[] { Time.time });

                if (__instance.Owner.Memory.GoalEnemy == null)
                {
                    __instance.Owner.BotsGroup.CalcGoalForBot(__instance.Owner);
                }

                // Default code that isn't being used now
                ETagStatus? additionaMask = null;
                if (__instance.Owner.Memory.GoalEnemy != null)
                {
                    switch (__instance.Owner.Memory.GoalEnemy.Person.GetPlayer.Profile.Info.Side)
                    {
                        case EPlayerSide.Usec:
                            additionaMask = new ETagStatus?(ETagStatus.Usec);
                            break;
                        case EPlayerSide.Bear:
                            additionaMask = new ETagStatus?(ETagStatus.Bear);
                            break;
                        case EPlayerSide.Savage:
                            additionaMask = new ETagStatus?(ETagStatus.Scav);
                            break;
                    }
                }
                // End of unused code

                int num = 0;
                foreach (KeyValuePair<IAIDetails, GClass475> keyValuePair in __instance.Owner.EnemiesController.EnemyInfos)
                {
                    if (keyValuePair.Value.IsVisible)
                    {
                        num++;
                    }
                }
                if (num > UnityEngine.Random.Range(1f, 2f))
                {
                    __instance.Owner.GetPlayer.Say(EPhraseTrigger.Spreadout, false, 0.5f, ETagStatus.Combat, 25, true);
                }

                // Taunt
                if (__instance.HaveSeen)
                {
                    __instance.Owner.GetPlayer.Say(EPhraseTrigger.MumblePhrase, false, 0.1f, ETagStatus.Combat, 50, true);
                }
                else
                {
                    // Next shot miss
                    if (Vector3.Dot(__instance.Owner.LookDirection, __instance.Person.LookDirection) > 0f)
                    {
                        //__instance.Owner.AimingData.NextShotMiss();
                    }

                    // Group Talk
                    if (__instance.Owner.BotsGroup.GroupTalk.CanSay(__instance.Owner, EPhraseTrigger.OnFirstContact))
                    {
                        __instance.Owner.GetPlayer.Say(EPhraseTrigger.OnFirstContact, false, 0.25f, ETagStatus.Combat, 25, true);
                    }
                }
                __instance.Owner.BotPersonalStats.AddGetVision(__instance.Owner, __instance);
                __instance.GroupOwner.GetVision();
            }

            // New - Enemy rat!
            if (__instance.Owner.Memory.GoalEnemy != null)
            {
                if (__instance.Owner.Memory.GoalEnemy.TimeLastSeen < Time.time + 10f)
                {
                    __instance.Owner.GetPlayer.Say(EPhraseTrigger.Rat, false, 0f, ETagStatus.Aware, 50, true);
                }
            }

            return false;
        }
    }
    public class UpdateRatePatch : ModulePatch
    {
        protected override MethodBase GetTargetMethod()
        {
            return AccessTools.Method(typeof(GClass115), "Update");
        }

        [PatchPrefix]
        public static void PatchPrefix(GClass115 __instance, ref float ___float_0)
        {
            if (___float_0 > Time.time + 1f) ___float_0 = Time.time + 1f;
        }
    }
}